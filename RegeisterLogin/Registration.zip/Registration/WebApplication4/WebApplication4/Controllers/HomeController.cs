﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebApplication4.Models;

namespace WebApplication4.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }

        public ActionResult Register()
        {
            ViewBag.Message = "Your Register page.";
            
            return View();
        }
        [HttpPost]
        public ActionResult Register(Home h)
        {
            ViewBag.Message = "Your Register page.";
            string fname = h.Firstname;
            string lname = h.Lastname;
            string mail = h.Email;
            string gender = h.Gender;
            string add = h.Address;
            bool hobby = h.Hobbies;
            string city = h.City;
            return View();
        }

        public ActionResult MyPage()
        {
            ViewBag.Message = "My page.";

            return View();
        }
    }
}